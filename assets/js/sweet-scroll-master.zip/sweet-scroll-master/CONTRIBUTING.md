# Contributing `sweet-scroll`

Thank you for contributing `sweet-scroll` :tada:

## Templates

Please use issue/PR templates which are inserted automatically.

## Found a Bug?

If you find a bug in the source code, you can help us by [submitting an issue](https://github.com/sweet-scroll/sweet-scroll/issues) to our [GitHub Repository](https://github.com/sweet-scroll/sweet-scroll). Even better, you can submit a Pull Request with a fix.
