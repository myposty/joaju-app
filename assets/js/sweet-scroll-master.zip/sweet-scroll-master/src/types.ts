export type ScrollableElement = Element | Window;
