export declare const canUseDOM: boolean;
export declare const canUseHistory: boolean;
export declare const canUsePassiveOption: boolean;
