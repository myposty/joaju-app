export declare type ScrollableElement = Element | Window;
